from openrgb import OpenRGBClient
from openrgb.utils import RGBColor

class OpenRGBBackend:
    def __init__(self):
        self.client = OpenRGBClient()

    def push_frame(self, frame):
        i = 0
        for device in self.client.devices:
            leds = device.leds
            colors = []
            for _ in leds:
                if i < len(frame):
                    r, g, b = frame[i]
                    colors.append(RGBColor(r, g, b))
                i += 1
            if colors:
                device.set_colors(colors)
