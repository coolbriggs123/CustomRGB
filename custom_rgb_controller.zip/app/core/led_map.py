class LogicalLED:
    def __init__(self, id, x, y):
        self.id = id
        self.x = x
        self.y = y
