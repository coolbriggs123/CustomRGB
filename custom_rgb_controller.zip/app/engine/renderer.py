import time

def blend(a, b, alpha):
    return (
        int(a[0]*(1-alpha) + b[0]*alpha),
        int(a[1]*(1-alpha) + b[1]*alpha),
        int(a[2]*(1-alpha) + b[2]*alpha)
    )

def render_loop(leds, effects, backend, fps=60):
    start = time.perf_counter()
    while True:
        t = time.perf_counter() - start
        frame = [(0,0,0)] * len(leds)

        for effect in effects:
            if not effect.enabled:
                continue
            ef = effect.render(leds, t)
            frame = [blend(frame[i], ef[i], effect.opacity) for i in range(len(frame))]

        backend.push_frame(frame)
        time.sleep(1/fps)
