from .base import Effect

class SolidColor(Effect):
    def __init__(self, color):
        self.color = color

    def render(self, leds, t):
        return [self.color for _ in leds]
