class Effect:
    enabled = True
    opacity = 1.0

    def render(self, leds, t):
        raise NotImplementedError
