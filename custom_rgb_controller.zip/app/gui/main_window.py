import threading
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QColorDialog
from app.backend.openrgb_backend import OpenRGBBackend
from app.effects.solid import SolidColor
from app.engine.renderer import render_loop

def run_app():
    app = QApplication([])

    backend = OpenRGBBackend()
    leds = list(range(sum(len(d.leds) for d in backend.client.devices)))
    effects = [SolidColor((255,0,0))]

    t = threading.Thread(target=render_loop, args=(leds, effects, backend), daemon=True)
    t.start()

    win = QWidget()
    win.setWindowTitle("Custom RGB Controller")
    layout = QVBoxLayout(win)

    def pick_color():
        color = QColorDialog.getColor()
        if color.isValid():
            effects[0].color = (color.red(), color.green(), color.blue())

    btn = QPushButton("Pick Color")
    btn.clicked.connect(pick_color)
    layout.addWidget(btn)

    win.show()
    app.exec()
