# Custom RGB Controller

Python-based RGB controller inspired by OpenRGB (hardware abstraction)
and Artemis (effects engine).

## Requirements
- Windows
- OpenRGB running with SDK server enabled
- Python 3.11+

## Install
pip install -r requirements.txt

## Run
python main.py
