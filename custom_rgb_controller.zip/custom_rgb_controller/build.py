import os
import subprocess
import sys
import shutil
import json

def check_pyinstaller():
    try:
        import PyInstaller
        print("PyInstaller is installed.")
        return True
    except ImportError:
        print("PyInstaller is not installed. Installing...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
            print("PyInstaller installed successfully.")
            return True
        except Exception as e:
            print(f"Failed to install PyInstaller: {e}")
            return False

def build():
    if not check_pyinstaller():
        return

    # Define build options
    script_file = "C:\\Users\\rbawe\\Documents\\Python\\custom_rgb_controller\\main.py"
    app_name = "CustomRGBController"
    
    # PyInstaller arguments
    args = [
        "pyinstaller",
        "--noconsole",
        "--onefile",
        "--name", app_name,
        "--clean",
        "--collect-all", "qtawesome", # Ensure qtawesome fonts are collected
        "--hidden-import", "openrgb",
        "--hidden-import", "soundcard",
        "--hidden-import", "numpy",
        script_file
    ]

    print(f"Running: {' '.join(args)}")
    
    try:
        subprocess.check_call(args)
        print("Build complete.")
        
        # Post-build: Copy settings.json to dist folder
        dist_dir = "dist"
        if not os.path.exists(dist_dir):
            os.makedirs(dist_dir)

        settings_src = "settings.json"
        settings_dst = os.path.join(dist_dir, "settings.json")
        
        if os.path.exists(settings_src):
            shutil.copy2(settings_src, settings_dst)
            print(f"Copied {settings_src} to {dist_dir}")
        else:
            # Create a default one if missing
            default_settings = {
                "brightness": 1.0,
                "identify_device": -1,
                "fps_limit": 60,
                "minimize_to_tray": True,
                "start_minimized": False,
                "auto_connect": True,
                "openrgb_host": "127.0.0.1",
                "openrgb_port": 6742,
                "theme": "Dark"
            }
            with open(settings_dst, 'w') as f:
                json.dump(default_settings, f, indent=4)
            print(f"Created default settings.json in {dist_dir}")

        # Ensure profiles directory exists in dist (optional, but good for UX)
        profiles_dst = os.path.join(dist_dir, "profiles")
        if not os.path.exists(profiles_dst):
            os.makedirs(profiles_dst)
            print(f"Created profiles directory in {dist_dir}")

        print(f"\nExecutable created in '{os.path.abspath(dist_dir)}' folder.")
        print("IMPORTANT: 'settings.json' must be in the same folder as the executable.")
        
    except subprocess.CalledProcessError as e:
        print(f"Build failed with error code {e.returncode}")

if __name__ == "__main__":
    build()
